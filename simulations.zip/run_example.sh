#!/usr/bin/env bash
# Catalog case: use real CHIME FRB positions from a text file
POSITION_SOURCE=catalog \
POSITIONS_PATH=data/chimefrbcat2_radec.txt \
CL_PATH=data/cell_chime.npz \
N_REALISATIONS=100 \
NSIDE=256 \
python generate_mock_catalogues.py

# Mask case: sample positions from a detection-probability mask
POSITION_SOURCE=mask \
POSITION_MASK_PATH=output/chime/detection_probability_mask_nside128.fits \
POSITION_MASK_MODE=fixed \
N_SOURCES=5000 \
CL_PATH=data/cell_chime.npz \
N_REALISATIONS=100 \
NSIDE=256 \
python generate_mock_catalogues.py
